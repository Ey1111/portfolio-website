(function installAncillaCollector(root) {
  if (root.__ancillaLensCollectorInstalled) return
  root.__ancillaLensCollectorInstalled = true

  function meta(name) {
    return document.querySelector(`meta[name="${name}"]`)?.content
      || document.querySelector(`meta[property="${name}"]`)?.content
      || ''
  }

  function pageAttributes() {
    const node = document.querySelector('[data-ancilla-product]')
    if (!node) return {}
    return {
      productName: node.dataset.productName,
      flightNo: node.dataset.flightNo,
      salePrice: node.dataset.salePrice,
      benchmarkPrice: node.dataset.benchmarkPrice,
      originCode: node.dataset.originCode,
      destinationCode: node.dataset.destinationCode,
      category: node.dataset.category,
      cabinCodes: node.dataset.cabinCodes,
      effectiveFrom: node.dataset.effectiveFrom,
      effectiveTo: node.dataset.effectiveTo,
      entitlementText: node.dataset.entitlementText,
      configuredEntitlement: node.dataset.configuredEntitlement,
    }
  }

  function collect() {
    const snapshot = {
      url: location.href,
      title: meta('og:title') || document.querySelector('h1')?.textContent || document.title,
      description: meta('description') || meta('og:description'),
      text: document.body?.innerText?.slice(0, 12000) || '',
      attributes: pageAttributes(),
    }
    return root.AncillaLensExtractor.extractSnapshot(snapshot)
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'ANCILLA_COLLECT') return false
    try { sendResponse({ ok: true, payload: collect() }) }
    catch (error) { sendResponse({ ok: false, error: error instanceof Error ? error.message : '页面解析失败' }) }
    return true
  })

  let mutationTimer
  const observer = new MutationObserver(() => {
    clearTimeout(mutationTimer)
    mutationTimer = setTimeout(() => chrome.runtime.sendMessage({ type: 'ANCILLA_PAGE_CHANGED' }).catch(() => undefined), 1200)
  })
  if (document.documentElement) observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true })
})(globalThis)
