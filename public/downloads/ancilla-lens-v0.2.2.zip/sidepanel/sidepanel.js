(function startLensPanel() {
  const API_BASE = 'https://hangyi-zhishen.ancilla-guard.workers.dev'
  const hasChrome = typeof chrome !== 'undefined' && Boolean(chrome.tabs && chrome.scripting)
  const client = globalThis.AncillaLensClient.create({ apiBase: API_BASE, offlineAnalyzer: globalThis.AncillaLensRules.analyzeAncillary })
  const authView = document.querySelector('#auth-view')
  const reviewView = document.querySelector('#review-view')
  const analysisView = document.querySelector('#analysis-view')
  const sessionButton = document.querySelector('#session-button')
  const scanButton = document.querySelector('#scan-button')
  const scanError = document.querySelector('#scan-error')
  let session
  let currentPayload
  let scanTimer

  function text(id, value) { document.querySelector(`#${id}`).textContent = value }
  function showReview(nextSession) {
    session = nextSession
    authView.hidden = true
    reviewView.hidden = false
    sessionButton.hidden = false
    text('mode-label', session.token ? `云端 · ${session.user?.name ?? '已登录'}` : '离线规则 · 不上传')
  }
  function showError(message) { scanError.textContent = message; scanError.hidden = false }
  function clearError() { scanError.textContent = ''; scanError.hidden = true }
  function riskLabel(risk) { return risk === 'high' ? '高风险' : risk === 'medium' ? '中风险' : '低风险' }
  function platformLabel(platform) { return platform === 'ctrip-web-adapter' ? 'CTRIP WEB ADAPTER' : platform === 'umetrip-web-adapter' ? 'UMETRIP WEB ADAPTER' : 'GENERIC WEB ADAPTER' }

  function previewPayload() {
    if (new URLSearchParams(location.search).get('demo') === 'ctrip') {
      return {
        productName: '东方航空 MU5185 经济舱', flightNo: 'MU5185', salePrice: 437,
        originCode: 'SHA', destinationCode: 'BJS', category: '机票票价', cabinCodes: ['经济舱'],
        entitlementText: '行程保障 · 价格保障 · 7*24小时客服 · 应急援助',
        platform: 'ctrip-web-adapter', sourceUrl: 'https://flights.ctrip.com/booking/SHA-BJS-day-1.html', confidence: 'high',
      }
    }
    return { productName: '国际航线贵宾休息室', flightNo: 'MU5101', salePrice: 220, benchmarkPrice: 160, originCode: 'SHA', destinationCode: 'PEK', category: '贵宾休息室', cabinCodes: ['Y', 'B'], effectiveFrom: '2026-09-01', effectiveTo: '2026-12-31', entitlementText: '休息室与快速安检', configuredEntitlement: '仅休息室', platform: 'generic-web', sourceUrl: location.href, confidence: 'high' }
  }

  function renderAnalysis(payload, result) {
    currentPayload = payload
    const analysis = result.analysis
    analysisView.hidden = false
    text('platform-label', `${platformLabel(payload.platform)} · ${result.mode.toUpperCase()}`)
    text('product-name', analysis.productName)
    text('flight-route', `${payload.flightNo || '待识别航班'}${payload.originCode || payload.destinationCode ? ` · ${payload.originCode || '—'} → ${payload.destinationCode || '—'}` : ''}`)
    text('sale-price', payload.salePrice ? `¥${payload.salePrice}` : '未识别')
    text('benchmark-price', payload.benchmarkPrice ? `¥${payload.benchmarkPrice}` : '待补充')
    text('cabin-codes', payload.cabinCodes?.join(' / ') || '待补充')
    text('confidence', globalThis.AncillaLensExtractor.confidenceLabel(payload.confidence))
    text('analysis-time', new Date(analysis.analyzedAt).toLocaleTimeString('zh-CN', { hour12: false }))
    text('summary-text', analysis.summary)
    const badge = document.querySelector('#risk-badge')
    badge.className = `risk-badge ${analysis.risk}`
    badge.textContent = riskLabel(analysis.risk)
    document.querySelector('#rules-list').replaceChildren(...analysis.rules.map((rule) => {
      const row = document.createElement('article')
      row.className = 'rule-row'
      const rail = document.createElement('i'); rail.className = rule.result
      const copy = document.createElement('span')
      const strong = document.createElement('strong'); strong.textContent = rule.label
      const small = document.createElement('small'); small.textContent = rule.finding
      copy.append(strong, small)
      const state = document.createElement('em'); state.textContent = rule.result === 'passed' ? 'PASS' : rule.result.toUpperCase()
      row.append(rail, copy, state)
      return row
    }))
    const form = document.querySelector('#field-form')
    form.elements.productName.value = payload.productName || ''
    form.elements.salePrice.value = payload.salePrice || ''
    form.elements.benchmarkPrice.value = payload.benchmarkPrice || ''
    form.elements.flightNo.value = payload.flightNo || ''
    form.elements.cabinCodes.value = payload.cabinCodes?.join(',') || ''
  }

  async function analyze(payload) {
    const result = await client.analyze(payload, session?.token)
    renderAnalysis(payload, result)
  }

  async function collectFromPage() {
    clearError()
    scanButton.disabled = true
    scanButton.textContent = '正在读取当前页面…'
    try {
      if (!hasChrome) {
        const preview = previewPayload()
        text('page-domain', preview.platform === 'ctrip-web-adapter' ? 'CTRIP / flights.ctrip.com' : 'PREVIEW / flights.example.com')
        await analyze(preview)
        return
      }
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      const tabId = globalThis.AncillaLensExtractor.scannableTabId(tab)
      await chrome.scripting.executeScript({ target: { tabId }, files: ['lib/extractor.js', 'content/collector.js'] })
      const response = await chrome.tabs.sendMessage(tabId, { type: 'ANCILLA_COLLECT' })
      if (!response?.ok) throw new Error(response?.error || '当前页面无法解析')
      text('page-domain', tab.url ? new URL(tab.url).hostname : '当前活动页面')
      await analyze(response.payload)
    } catch (error) {
      showError(`${error instanceof Error ? error.message : '扫描失败'}。可在支持页面加入 data-ancilla-product 标记，或扫描后手动修正字段。`)
    } finally {
      scanButton.disabled = false
      scanButton.textContent = '重新扫描当前页面'
    }
  }

  document.querySelector('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault()
    const button = event.currentTarget.querySelector('button[type="submit"]')
    const errorNode = document.querySelector('#login-error')
    button.disabled = true; button.textContent = '正在建立安全会话…'; errorNode.textContent = ''
    try {
      const next = await client.login(document.querySelector('#email').value, document.querySelector('#password').value)
      await chrome.storage.session.set({ ancillaLensSession: next })
      showReview(next)
    } catch (error) { errorNode.textContent = error instanceof Error ? error.message : '登录失败' }
    finally { button.disabled = false; button.textContent = '连接云端审核' }
  })
  document.querySelector('#offline-button').addEventListener('click', () => showReview({ user: { name: '离线模式' } }))
  sessionButton.addEventListener('click', async () => {
    if (hasChrome) await chrome.storage.session.remove('ancillaLensSession')
    session = undefined; reviewView.hidden = true; authView.hidden = false; sessionButton.hidden = true; analysisView.hidden = true
  })
  scanButton.addEventListener('click', () => void collectFromPage())
  document.querySelector('#field-form').addEventListener('submit', (event) => {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const corrected = { ...currentPayload, productName: String(data.get('productName')), salePrice: Number(data.get('salePrice')), benchmarkPrice: Number(data.get('benchmarkPrice')) || undefined, flightNo: String(data.get('flightNo')), cabinCodes: String(data.get('cabinCodes')).split(',').map((item) => item.trim()).filter(Boolean), confidence: 'manual' }
    void analyze(corrected)
  })
  if (hasChrome) {
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type !== 'ANCILLA_PAGE_CHANGED' || !session) return
      clearTimeout(scanTimer); scanTimer = setTimeout(() => void collectFromPage(), 700)
    })
    chrome.storage.session.get('ancillaLensSession').then(({ ancillaLensSession }) => { if (ancillaLensSession) showReview(ancillaLensSession) })
  } else {
    showReview({ user: { name: '预览模式' } })
    void collectFromPage()
  }
})()
